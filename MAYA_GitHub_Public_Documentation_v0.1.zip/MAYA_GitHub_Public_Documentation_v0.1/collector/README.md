# MAYA Collector

This directory is part of the public MAYA research repository.

Implementation and examples will be added as each component reaches the corresponding development milestone.
