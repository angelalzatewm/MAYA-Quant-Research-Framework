# MAYA Architecture

## 1. Architectural intent

MAYA is designed as a sequence of controlled research stages. Each stage has a different responsibility and a different evidentiary standard.

```text
COLLECTOR
   ↓
EDA-LITE
   ↓
MAYA CORE
   ↓
MAYA HUNTER
```

The pipeline is intentionally not a single monolithic machine-learning script.

## 2. MAYA Collector

### Responsibility

Collect event-level market observations and perform feature engineering close to the source.

### Expected responsibilities

- event detection;
- fixing/range construction;
- decision-time feature capture;
- cross-asset and higher-timeframe features;
- volatility and range features;
- spread/flow proxies;
- first-touch MFE/MAE timing;
- data-quality status.

The current EDA-Lite package is explicitly grounded in the Collector CSV schema, including `Event_ID`, event timestamps, feature columns, first-touch barrier columns and outcome fields. 

### Important boundary

Collector produces the research dataset.

Collector does **not** certify an edge.

---

## 3. EDA-Lite

### Responsibility

Rapid candidate discovery.

EDA-Lite should answer:

> "Which asset/profile/hypothesis combinations show enough preliminary evidence to justify deeper research?"

### Typical components

```text
DataLoader
DataQuality
FastScreen
LabelEngine / TBM-Lite
EDA diagnostics
WFO-Lite
RandomForest-Lite
Monte Carlo
Robustness-Lite
Economic-Lite
Surrogate-Lite
Candidate Registry
Multiple Testing
```

The current public design intentionally avoids becoming a second full MAYA Core. It uses simpler model/search settings while retaining temporal controls and statistical safeguards.

### Output

```text
REJECTED
CANDIDATE
STRONG_CANDIDATE
```

These statuses represent **research triage**, not production approval.

---

## 4. MAYA Core

### Responsibility

MAYA Core is the rigorous validation layer.

Core asks:

> "Does this candidate remain defensible under a stricter and more comprehensive validation protocol?"

Expected controls include:

- stronger cross-validation design;
- purging and embargo where appropriate;
- more careful hyperparameter governance;
- robustness testing;
- multiple-testing control;
- economic validation;
- stability analysis;
- reproducibility;
- certification rules.

### Certification meaning

A Core-certified candidate does **not** mean:

> "This strategy is guaranteed to make money."

It means:

> "Under the declared MAYA validation protocol, the candidate satisfied the requirements defined for certification."

---

## 5. MAYA Hunter

### Responsibility

Evaluate an already-defined candidate using previously unseen data and the real execution assumptions of the system.

Hunter is the bridge between:

```text
research
```

and:

```text
operational execution
```

Hunter should not be used as a hidden optimization engine.

Its most important role is to answer:

> "What happens when the candidate is frozen and exposed to genuinely unseen observations?"

---

## 6. Separation of responsibilities

| Layer | Primary question |
|---|---|
| Collector | What happened in the market? |
| EDA-Lite | Where might an edge exist? |
| Core | Is the candidate defensible under strict validation? |
| Hunter | Does the frozen candidate survive true OOS execution? |

---

## 7. Proposed repository architecture

```text
maya-quant-research-framework/
│
├── collector/
│   ├── src/
│   ├── tests/
│   └── README.md
│
├── eda_lite/
│   ├── src/
│   ├── tests/
│   └── README.md
│
├── maya_core/
│   ├── src/
│   ├── tests/
│   └── README.md
│
├── maya_hunter/
│   ├── src/
│   ├── tests/
│   └── README.md
│
├── docs/
├── examples/
├── configs/
└── tests/
```

---

## 8. Future architecture

The long-term infrastructure may add:

```text
Experiment Registry
Model Registry
Artifact Store
Research Database
CI/CD
Parameter Governance
Monitoring
Live/Shadow Evaluation
Report Generation
```

These should be added only when the corresponding contracts and tests are defined.
