# MAYA Research Plan

## Immediate objective

Finish calibration of EDA-Lite while preserving the four-stage separation:

```text
Collector → Discovery → Strict Validation → True OOS
```

## Workstream A — EDA-Lite

### A1. Temporal governance
Implement:

```text
Discovery 2016–2022
Internal Validation 2023
OOS 2024+
```

as executable boundaries.

### A2. Candidate economics
Make the economics stage consume:

```text
OOF candidate decisions
```

rather than all labeled observations.

### A3. Registry semantics
Separate:

```text
dataset coverage
label coverage
candidate coverage
trade coverage
```

and define each mathematically.

### A4. Robustness
Use financial returns for financial drawdown metrics.

### A5. Surrogate
Verify:

```text
surrogate vs RF
surrogate vs truth
```

on unseen data and preserve the exact rule hash.

---

## Workstream B — Core

Define a formal certification protocol.

Potential sequence:

```text
Candidate
   ↓
data audit
   ↓
purged validation
   ↓
nested model governance
   ↓
robustness
   ↓
multiple testing
   ↓
economic validation
   ↓
reproducibility audit
   ↓
OOS eligibility
```

---

## Workstream C — Hunter

Define a frozen candidate handoff.

Hunter should consume a machine-readable artifact that completely specifies:

- the rule/model;
- input features;
- timing;
- execution assumptions;
- risk assumptions;
- code/data hashes;
- OOS start.

---

## Workstream D — Public portfolio

Publish:

- architecture;
- methodology;
- tests;
- synthetic examples;
- development history;
- research limitations.

Protect:

- proprietary full datasets;
- broker credentials;
- infrastructure secrets;
- sensitive production configurations;
- any strategy details you decide to keep private.
