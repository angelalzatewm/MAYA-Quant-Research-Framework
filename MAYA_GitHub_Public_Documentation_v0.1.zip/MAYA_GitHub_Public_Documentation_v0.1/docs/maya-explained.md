# MAYA Explained — From Candlestick Patterns to Quantitative Research

This document explains MAYA using simple trading language.

## 1. Start with a normal trading idea

A discretionary trader might look at a chart and say:

> "When this type of range forms and these conditions appear, price seems more likely to break upward."

That is not yet a strategy.

It is a **hypothesis**.

The central problem is that humans are very good at seeing patterns in historical charts. A quantitative framework exists to test whether the pattern survives objective controls.

---

## 2. Collector = the data collector

Imagine a scientist collecting thousands of samples from a river.

The scientist is not trying to prove anything yet.

The scientist is collecting observations.

MAYA Collector does the same thing with the market:

```text
Market
  ↓
Events
  ↓
Features
  ↓
Barrier outcomes
  ↓
Research CSV
```

For every event, the Collector stores information such as:

- event timestamps;
- range and volatility information;
- higher-timeframe features;
- cross-asset proxies;
- spread/flow proxies;
- MFE/MAE first-touch timing;
- data-quality status.

The Collector therefore creates the raw material for research.

---

## 3. EDA-Lite = looking for gold

Suppose Collector creates thousands of observations.

You could test every idea with the heaviest possible model, but that would be expensive and would encourage excessive search.

Instead, EDA-Lite performs **research triage**.

Think of it as gold prospecting:

```text
Large amount of data
        ↓
cheap / disciplined screening
        ↓
interesting candidates
```

It asks:

- Is there enough data?
- Is the relationship measurable?
- Does it survive temporal validation?
- Could it be more than noise?
- Does it remain economically interesting?

EDA-Lite does not claim to have proven the strategy.

It says:

> "This candidate deserves a deeper investigation."

---

## 4. MAYA Core = the laboratory

Now suppose EDA-Lite finds a promising candidate.

Core is the laboratory that applies stricter controls.

It asks:

```text
Could future information have leaked in?
Does the relationship survive time?
Does it survive different periods?
Does it survive costs?
Does it survive robustness tests?
Could multiple-testing explain the result?
Can we reproduce the result?
```

If the candidate survives the declared protocol, Core can mark it as **certifiable under MAYA's research rules**.

That is not the same as guaranteeing future profits.

---

## 5. MAYA Hunter = testing the idea in new territory

Now freeze the candidate.

Do not continue changing it because the new data are inconvenient.

Send the frozen candidate into a genuinely unseen period.

That is the role of Hunter.

```text
Candidate frozen
      ↓
New data
      ↓
Execution assumptions
      ↓
OOS result
```

Hunter asks:

> "Does the apparent edge survive after it leaves the laboratory?"

---

## 6. Why all four stages are needed

A complete research pipeline therefore looks like:

```text
COLLECTOR
"Collect the evidence"

EDA-LITE
"Find promising evidence"

CORE
"Challenge the evidence"

HUNTER
"Expose the frozen candidate to unseen evidence"
```

---

## 7. A practical example

Imagine a rule:

```text
XAUUSD
+
specific session profile
+
high range z-score
+
specific macro alignment
=
long candidate
```

Collector records the events.

EDA-Lite discovers that the condition appears associated with positive forward outcomes.

Core checks whether the relationship is robust and economically defensible.

Hunter then runs the frozen logic over a later unseen period.

Possible outcomes:

```text
Statistical evidence:   YES
Economic evidence:      YES
Core validation:        YES
True OOS persistence:   NO
```

This is not a failure of the research system.

It is a useful finding:

> the edge did not persist.

That is precisely the type of distinction MAYA is designed to make.

---

## 8. The four kinds of "edge"

MAYA separates four ideas that are often mixed together:

### Statistical edge

Evidence that a relationship is not easily explained by the chosen null model.

### Economic edge

The relationship remains attractive after the declared cost assumptions.

### Executable edge

The evidence can be converted into a deterministic rule that Hunter can execute.

### Persistent/live edge

The frozen rule continues to work when exposed to genuinely new observations.

A candidate can pass one layer and fail another.

---

## 9. The simple mental model

If you remember only one thing:

> **Collector collects. EDA-Lite discovers. Core challenges and certifies. Hunter tests the frozen candidate in the real world of unseen data.**

That is the whole MAYA philosophy in one sentence.
