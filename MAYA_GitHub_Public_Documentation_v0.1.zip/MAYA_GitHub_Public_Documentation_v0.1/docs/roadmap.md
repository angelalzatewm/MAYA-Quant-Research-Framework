# MAYA Roadmap

## Vision

Evolve MAYA from a research prototype into a reproducible quantitative research infrastructure.

---

## Phase 0 — Public Research Blueprint

**Status: NOW**

- public repository;
- architecture documentation;
- methodology documentation;
- research governance;
- roadmap;
- transparent status;
- synthetic examples where possible.

---

## Phase 1 — Stabilize MAYA Collector

**Goal**

Create a well-defined and reproducible market-event data contract.

### Deliverables

- documented Collector schema;
- deterministic feature definitions;
- data-quality rules;
- event lifecycle documentation;
- reproducible sample dataset;
- Collector tests where technically feasible.

---

## Phase 2 — EDA-Lite Calibration

**Goal**

Complete the current discovery layer without turning it into an over-optimized research engine.

### Priority work

- complete Discovery → Freeze → Internal Validation flow;
- ensure economics are evaluated on candidate OOF decisions;
- finalize trade/candidate coverage definitions;
- finalize multiple-testing reporting;
- verify robustness metrics;
- finish surrogate parity checks;
- run reproducible smoke/integration tests.

---

## Phase 3 — MAYA Core

**Goal**

Build the stricter validation and certification layer.

### Deliverables

- formal validation protocol;
- stronger purged validation;
- nested/controlled model selection where justified;
- robustness and stability analysis;
- multiple-testing governance;
- reproducible certification reports;
- explicit `OOS_ELIGIBLE` criteria.

---

## Phase 4 — MAYA Hunter

**Goal**

Move frozen candidates into genuine OOS evaluation.

### Deliverables

- candidate ingestion contract;
- deterministic rule execution;
- real execution assumptions;
- slippage/commission/spread model;
- OOS reporting;
- trade-level audit trail;
- monitoring.

---

## Phase 5 — Research Infrastructure

Potential future components:

```text
Experiment Registry
Model Registry
Artifact Registry
Research Database
Automated Reports
CI
Data Versioning
Cloud / VPS execution
Monitoring
Shadow Mode
```

---

## Phase 6 — Productization

Only after methodology and reproducibility are mature:

- reproducible research jobs;
- strategy research APIs;
- team collaboration;
- audit trails;
- experiment dashboards;
- controlled deployment;
- research cost monitoring.

---

## Funding / infrastructure vision

Long-term infrastructure requirements may include:

```text
CPU/RAM compute
storage
market data
VPS/cloud infrastructure
development tooling
CI/CD resources
research monitoring
artifact storage
```

The project should remain honest about its current maturity. Funding is intended to accelerate infrastructure and research capacity, not to manufacture performance claims.
