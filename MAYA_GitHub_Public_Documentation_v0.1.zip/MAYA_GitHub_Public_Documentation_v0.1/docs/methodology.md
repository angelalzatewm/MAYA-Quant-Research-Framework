# MAYA Methodology

## 1. Research objective

MAYA is intended to reduce false discoveries in systematic trading research by enforcing explicit separation between:

```text
data collection
discovery
validation
out-of-sample evaluation
```

The framework is not designed to guarantee profitability.

---

## 2. Data source contract

The current EDA-Lite implementation consumes the real Collector CSV schema rather than rebuilding Collector features downstream.

Important fields include:

```text
Event_ID
Fixing_Start_Time
Fixing_End_Time
Detection_Time
Decision_Time
Min_MFE_*
Min_MAE_*
Breakout_Dir
MFE_Pts_Net
MAE_Pts_Net
MFE_Net_Range_Ratio
MAE_Net_Range_Ratio
Close_vs_Range_State
Data_Quality_Status
```

The current design explicitly treats `Min_MFE_*` / `Min_MAE_*` as first-touch timing fields referenced to `Decision_Time`, with `-1` representing a barrier that was never touched. The label layer converts the sentinel into missing/unavailable information before comparing barrier order. 

---

## 3. Causal feature discipline

Features used for prediction must be available at or before the model decision time.

Post-outcome variables must never become predictive inputs.

Examples of outcome-only fields:

```text
Breakout_Dir
MFE_Pts_Net
MAE_Pts_Net
MFE_Net_Range_Ratio
MAE_Net_Range_Ratio
Close_vs_Range_State
```

The research system must not use future-state variables to filter training observations.

---

## 4. Event-based labeling

The label should be defined from barrier timing rather than from a future state filter.

Conceptually:

```text
TP first  → positive
SL first  → negative
Neither   → unlabeled / excluded according to the hypothesis contract
```

The event's label end should reflect the actual barrier horizon whenever such an event-based horizon is available.

---

## 5. Temporal governance

The intended research separation is:

```text
DISCOVERY
2016–2022

INTERNAL VALIDATION
2023

TRUE OOS
2024+
```

This separation is a governance rule, not merely a reporting convention.

A future implementation should physically prevent the discovery stage from consuming the true OOS period.

---

## 6. WFO-Lite

EDA-Lite uses lightweight walk-forward validation.

The important principle is retained:

> **"Lite" reduces model/search complexity; it does not remove temporal discipline.**

The WFO layer should use event-aware purging so that overlapping label horizons do not leak information between train and test.

---

## 7. RandomForest-Lite

The discovery model should remain intentionally simple.

Current direction:

```text
Random Forest
fixed conservative configuration
limited hyperparameter search
OOF predictions
```

The purpose is to detect candidate structure, not to maximize in-sample fit.

---

## 8. Monte Carlo

Monte Carlo is used as a challenge to the observed score.

The current EDA-Lite design uses:

```text
1,000 permutations → screening
10,000 permutations → confirmation
```

The Monte Carlo stage is explicitly framed as a test of the frozen model under the pooled WFO-Lite OOF setup, not as a magical guarantee that the entire research process is free of selection effects.

More permutations do not repair leakage or poor experimental design.

---

## 9. Multiple testing

A large research universe can produce apparently impressive results by chance.

Therefore the experiment registry should record:

```text
number of tested experiments
raw p-value
testing family
rank
adjusted / q-value
```

The project should clearly distinguish:

```text
raw evidence
```

from:

```text
evidence after multiplicity controls
```

and should not describe post-selection corrections as formal selective-inference guarantees unless the corresponding methodology is actually implemented.

---

## 10. Robustness

A candidate should not be judged by a single average score.

Useful dimensions include:

- fold stability;
- worst-fold performance;
- median-fold performance;
- year stability;
- profile stability;
- parameter-neighborhood behavior;
- economic drawdown using actual trade returns.

A metric computed from classification scores such as MCC should not be represented as financial drawdown.

---

## 11. Economic evaluation

Economic evaluation must match the decision rule being evaluated.

The correct conceptual sequence is:

```text
OOF model / rule
       ↓
selected candidate trades
       ↓
barrier result
       ↓
cost model
       ↓
net R
       ↓
expectancy / PF / drawdown
```

A dataset-wide barrier statistic is not sufficient evidence that the candidate rule itself is economically attractive.

The cost model should be explicitly calibrated before interpreting spread adjustments as real execution costs.

---

## 12. Surrogate models

The surrogate exists to compress a complex model into a human-readable rule.

It should be evaluated out of sample.

Useful evidence includes:

```text
fidelity to RF
MCC against truth
coverage
rule complexity
feature order
rule hash
```

A high-fidelity surrogate is an interpretability result. It is not, by itself, evidence of profitability.

---

## 13. Candidate status

Recommended semantics:

```text
REJECTED
    candidate failed a hard or research gate

CANDIDATE
    candidate shows enough evidence for continued research

STRONG_CANDIDATE
    candidate passed the discovery-stage gates and is ready
    for explicit next-stage validation, not automatic production
```

Core certification should be a separate status system from EDA-Lite.

---

## 14. Reproducibility

Every candidate should eventually have:

```text
dataset hash
feature schema/version
hypothesis definition
training period
decision period
label period
random seed
model configuration
code version / commit
rule hash
cost assumptions
validation results
```

A researcher should be able to answer:

> "Exactly how was this candidate generated?"

without relying on memory or undocumented manual steps.
