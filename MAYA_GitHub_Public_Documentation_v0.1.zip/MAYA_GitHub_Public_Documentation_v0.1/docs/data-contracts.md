# MAYA Data Contracts

## 1. Purpose

A major objective of MAYA is to make every module communicate through explicit, versioned contracts.

---

## 2. Collector → EDA-Lite

Minimum conceptual contract:

```text
Event_ID
Fixing_Start_Time
Fixing_End_Time
Detection_Time
Decision_Time
FEATURE_COLUMNS
MFE_COLUMNS
MAE_COLUMNS
OUTCOME_COLUMNS
Data_Quality_Status
```

The EDA-Lite implementation is currently grounded in the Collector CSV schema rather than recalculating Collector features downstream. 

---

## 3. Label contract

Label generation must declare:

```text
hypothesis_name
tp_R
sl_R
tp_column
sl_column
label_column
label_end_column
time_reference_column
```

Special rule:

```text
-1 = barrier not reached
```

and therefore cannot be interpreted as a valid first-touch time.

---

## 4. OOF contract

Every model candidate should expose, at minimum:

```text
event_id / index
test fold
y_true
y_proba
y_pred
decision timestamp
label end
```

Economic evaluation should consume the candidate's OOF decision signal, not merely the full labeled dataset.

---

## 5. Candidate contract

A candidate record should contain:

```text
candidate_id
asset
profile
hypothesis
features
rule
N_RAW
N_DQ_VALID
N_ELIGIBLE
N_LABELED
candidate_coverage
trade_coverage
MCC
PR_AUC
expectancy_R
profit_factor
max_drawdown_R
WFO stability
MC p-value
multiple-testing fields
surrogate fields
dataset hash
code version
training period
validation period
OOS boundary
status
reasons
```

---

## 6. Hunter input contract

The Hunter input should eventually include:

```text
candidate_id
rule / model
feature order
feature definitions
hypothesis execution mapping
risk parameters
cost assumptions
decision timing
OOS start
source dataset/code hash
```

The Hunter must not silently change research assumptions.

---

## 7. Versioning

Any change to a contract should increment a schema/version identifier.

Example:

```text
collector_schema = "maya-collector-v1"
candidate_schema = "maya-candidate-v1"
hunter_input_schema = "maya-hunter-v1"
```
