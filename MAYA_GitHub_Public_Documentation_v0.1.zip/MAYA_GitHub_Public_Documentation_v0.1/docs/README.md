# MAYA Documentation

## Core documents

- [Architecture](architecture.md)
- [MAYA Explained](maya-explained.md)
- [Methodology](methodology.md)
- [Research Governance](research-governance.md)
- [Data Contracts](data-contracts.md)
- [Risk & Limitations](risk-and-limitations.md)
- [Research Plan](research-plan.md)
- [Roadmap](roadmap.md)
- [Status](status.md)
