# MAYA Development Status

**Status date:** 2026-09-06  
**Overall stage:** Research Infrastructure / Active Development

## Component status

| Component | Current status | Notes |
|---|---|---|
| MAYA Collector | Research implementation | Produces event-level research data and features |
| EDA-Lite | **Calibration** | Candidate discovery pipeline under methodological refinement |
| MAYA Core | Architecture / validation development | Intended as the stricter certification layer |
| MAYA Hunter | Experimental | Intended for true OOS and execution evaluation |
| Production | **Not ready** | Requires completed contracts, tests, monitoring and validation |

## EDA-Lite current strengths

The current implementation includes:

- Collector schema grounding;
- explicit treatment of the `-1` first-touch sentinel;
- decision-time labeling reference;
- dynamic WFO purging;
- lightweight Random Forest;
- pooled WFO Monte Carlo;
- robustness analysis;
- economic module;
- OOS surrogate fidelity;
- candidate registry;
- batch multiple-testing metadata.

The project README documents these design goals explicitly. 

## Known work remaining

The current research branch should still be treated as calibration rather than final infrastructure.

Key open items include:

1. Implement the complete Discovery → Freeze → 2023 Internal Validation flow.
2. Ensure economic evaluation is applied to the selected OOF candidate decisions rather than to the full labeled event universe.
3. Correct the semantic definition of `trade_coverage`.
4. Replace any classification-score-based proxy for financial drawdown with trade-return-based drawdown.
5. Implement parameter-neighborhood robustness or explicitly label it as not tested.
6. Execute clean end-to-end reproducible tests in a controlled environment.
7. Define and freeze inter-module data contracts before public production claims are made.

## Interpretation policy

A `STRONG_CANDIDATE` produced by EDA-Lite is:

> a discovery-stage research candidate.

It is **not**:

- a guarantee of profitability;
- an institutional certification;
- a production strategy;
- evidence that the edge will persist.

## Next milestone

The next milestone is:

> **EDA-Lite v1.x methodology freeze**

Meaning:

- temporal governance is executable;
- candidate economics match candidate decisions;
- registry semantics are unambiguous;
- tests are reproducible;
- documentation matches the implemented behavior.
