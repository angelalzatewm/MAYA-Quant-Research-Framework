# MAYA Research Governance

## 1. Core principle

MAYA must distinguish between:

```text
Discovery
Validation
Confirmation
True OOS
Production
```

These are different evidentiary states.

---

## 2. Temporal firewall

The intended chronology is:

```text
2016–2022  Discovery
2023       Internal Validation
2024+      True OOS
```

The firewall should be enforced technically, not only stated in documentation.

---

## 3. Frozen candidate principle

Once a candidate enters a confirmation stage:

- features should be frozen;
- model configuration should be frozen;
- thresholds should be frozen;
- hypothesis definition should be frozen;
- cost assumptions should be frozen;
- the exact artifact/code version should be recorded.

Any change after freezing creates a new candidate.

---

## 4. Selection bias

The research process may test thousands of candidate combinations.

Therefore:

```text
raw p-value
```

is not automatically:

```text
probability that the candidate is real
```

The research record must retain the size and structure of the search universe.

---

## 5. Reporting discipline

Every result should answer:

1. What was tested?
2. What data period was allowed?
3. What information was available at decision time?
4. How many alternatives were tested?
5. What validation method was used?
6. What economic assumptions were used?
7. What was frozen before confirmation?
8. What remained genuinely unseen?

---

## 6. No retrospective tuning

A candidate must not be changed because of observed OOS performance and still be described as the same OOS experiment.

Once Hunter starts a declared OOS period:

> **the OOS period becomes evidence, not a tuning set.**

---

## 7. Public research policy

Public documentation should distinguish clearly between:

```text
current implementation
```

and:

```text
target architecture
```

Claims about production-readiness, institutional certification or persistent profitability should not be made before the corresponding evidence exists.
