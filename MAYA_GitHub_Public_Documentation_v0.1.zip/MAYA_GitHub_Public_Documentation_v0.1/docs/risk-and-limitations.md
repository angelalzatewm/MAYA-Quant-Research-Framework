# Risks and Limitations

MAYA is intentionally designed as a research infrastructure project. It has important limitations.

## Statistical risks

- multiple testing can create false discoveries;
- Monte Carlo does not fix leakage;
- a low p-value does not prove future profitability;
- model selection can introduce selection effects.

## Temporal risks

- overlapping event labels require careful purging;
- OOS boundaries must be enforced physically;
- a time-based split can still be invalid if features leak future information.

## Economic risks

- theoretical barrier P&L may differ from realized execution;
- spread, slippage and commissions vary by market and time;
- time stops and weekend gaps can alter real holding behavior.

## Model risks

- a surrogate can reproduce a model without proving that the model is economically correct;
- stable performance in historical regimes may fail in new regimes;
- simple models can still overfit when the research universe is large.

## Infrastructure risks

- dependency versions can change;
- data files can be corrupted or changed;
- non-deterministic execution can affect reproducibility;
- undocumented manual changes can invalidate research provenance.

## Interpretation

MAYA should be understood as a system for **reducing research error**, not as a machine that guarantees profitable trading.
